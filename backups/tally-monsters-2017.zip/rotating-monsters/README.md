
Rotating product monsters from Tally.
